import React from 'react';
import './App.css';
import RegisterForm from './components/RegisterForm';

function App() {
  return (
    <div className="App">
      <RegisterForm />
    </div>
  );
}

export default App;
