import React from 'react';
import './App.css';
import PokeButton from './components/PokeButton';

function App() {
  return (
    <div className="App">
      <PokeButton />
    </div>
  );
}

export default App;
